# APPX Uploader Bot

## Deploy
### Render  
[Deploy to Render](https://render.com/deploy)

### Railway  
[Deploy on Railway](https://railway.app/new)

### Koyeb  
[Deploy on Koyeb](https://app.koyeb.com/deploy)

## Features
- DRM / Non-DRM sorting
- ZIP / APPX Extract
- URL upload
- Channel auto-post
